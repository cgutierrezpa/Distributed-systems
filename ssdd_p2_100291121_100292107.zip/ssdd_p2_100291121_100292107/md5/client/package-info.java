@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.server.md5/")
package md5.client;
