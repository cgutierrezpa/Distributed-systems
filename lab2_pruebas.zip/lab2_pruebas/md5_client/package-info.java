@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.md5/")
package md5_client;
