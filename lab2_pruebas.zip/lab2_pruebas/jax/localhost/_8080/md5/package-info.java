@javax.xml.bind.annotation.XmlSchema(namespace = "http://localhost:8080/MD5")
package localhost._8080.md5;
