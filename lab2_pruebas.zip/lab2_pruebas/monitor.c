
#include "rpc_store_service/store_service.h"

int
main (int argc, char *argv[])
{
	char *host;
	enum clnt_stat retval; /* Return value for the getmessage call */

	if (argc < 3) {
		printf ("usage: %s server_host\n", argv[0]);
		exit (1);
	}

	host = "127.0.0.1";
	/* Get the ID from the third parameter and store it in an unsigned int */
	char *stopstring;
	unsigned int id = strtoul(argv[2], &stopstring, 10);

	CLIENT *clnt;

	clnt = clnt_create (host, STORE_SERVICE, STORE_VERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
	/* Allocate resources for the response */
	response *res = malloc(sizeof(response));
	res->msg = calloc(MAX_SIZE, sizeof(char));
	res->md5 = calloc(MAX_MD5, sizeof(char));
	retval = getmessage_1(argv[1], id, res, clnt);
	if(retval != RPC_SUCCESS) printf("ERROR , SERVICE NOT AVAILABLE\n");

	if(strlen(res->msg) == 0) printf ("ERROR , MESSAGE DOES NOT EXIST\n");
	else{
		printf("MESS: %s\n", res->msg);
		printf("MD5: %s\n", res->md5);
	}
	

	clnt_destroy (clnt);
	exit (0);
}
